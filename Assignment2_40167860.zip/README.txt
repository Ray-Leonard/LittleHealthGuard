How to RUN the project:
- Open UnityHub
- Select the folder where /Assets and /ProjectSettings are in
- Select a version of Unity (Game is built on 2020.3.3f1, so if you happen to have this version, would be nice)
- Then the project will open in UnityEditor.


-----------------------------------------------------
How to play the game:
- WASD to move
- Up,Down,Left,Right to use spray gun in four different directions, disinfect the boxes and stones
- Walk on the mask or vaccine to pick up, the currently holding item is displayed at the bottom right
- When in close contact with an NPC, you can use the following options:
	- SPACE to handout items (if NPC needed)
	- E to call ambulance to take away the RED NPC only

- Q to enter power mode, in which you move faster, can walk through walls and NPCs, ambulance CD and disinfect time will be extremely short
- T to use the infinity glove at a cost of 10 points. This will remove half of the Blue(fully vaccinated) NPCs in scene to make way for you. 
--------------------------------------------------------
About NPC:
Their vaccination and mask status is displayed on top of each NPC
Blue NPC = fully vaccinated with mask, no action needed. But can turn into highly dangerous NPC or infected NPC
Green NPC might need vaccine or both vaccine or mask
Pink NPC = highly dangerous NPC, need vaccine and mask, will die if being infected
Red NPC = infected NPC, will infect other NPC and the surfaces when in contact. 